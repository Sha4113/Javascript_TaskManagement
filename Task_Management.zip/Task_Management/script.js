let tasks = [];

function addTask() {
    const taskName = document.getElementById('task-name').value;
    const taskDesc = document.getElementById('task-desc').value;
    const taskDate = document.getElementById('task-date').value;

    if (taskName === '' || taskDate === '') {
        alert('Please enter task name and date.');
        return;
    }

    const task = {
        id: Date.now(),
        name: taskName,
        description: taskDesc,
        date: taskDate,
        completed: false
    };

    tasks.push(task);
    document.getElementById('task-name').value = '';
    document.getElementById('task-desc').value = '';
    document.getElementById('task-date').value = '';
    displayTasks();
}

function displayTasks() {
    const taskList = document.getElementById('task-list');
    taskList.innerHTML = '';

    tasks.forEach(task => {
        const li = document.createElement('li');
        li.className = task.completed ? 'completed' : '';
        li.innerHTML = `
            <span><strong>${task.name}</strong> - ${task.description} (Due: ${task.date})</span>
            <div>
                <button class="complete-btn" onclick="completeTask(${task.id})">Complete</button>
                <button class="edit-btn" onclick="editTask(${task.id})">Edit</button>
                <button class="delete-btn" onclick="deleteTask(${task.id})">Delete</button>
            </div>
        `;
        taskList.appendChild(li);
    });
}

function completeTask(id) {
    const task = tasks.find(task => task.id === id);
    task.completed = !task.completed;
    displayTasks();
}

function deleteTask(id) {
    tasks = tasks.filter(task => task.id !== id);
    displayTasks();
}

function editTask(id) {
    const task = tasks.find(task => task.id === id);
    document.getElementById('task-name').value = task.name;
    document.getElementById('task-desc').value = task.description;
    document.getElementById('task-date').value = task.date;
    deleteTask(id);
}

function searchTask() {
    const searchTerm = document.getElementById('search-task').value.toLowerCase();
    const filteredTasks = tasks.filter(task => task.name.toLowerCase().includes(searchTerm) || task.description.toLowerCase().includes(searchTerm));
    displayFilteredTasks(filteredTasks);
}

function filterTasks(status) {
    let filteredTasks = [];
    if (status === 'all') {
        filteredTasks = tasks;
    } else if (status === 'completed') {
        filteredTasks = tasks.filter(task => task.completed);
    } else {
        filteredTasks = tasks.filter(task => !task.completed);
    }
    displayFilteredTasks(filteredTasks);
}

function displayFilteredTasks(filteredTasks) {
    const taskList = document.getElementById('task-list');
    taskList.innerHTML = '';

    filteredTasks.forEach(task => {
        const li = document.createElement('li');
        li.className = task.completed ? 'completed' : '';
        li.innerHTML = `
            <span><strong>${task.name}</strong> - ${task.description} (Due: ${task.date})</span>
            <div>
                <button class="complete-btn" onclick="completeTask(${task.id})">Complete</button>
                <button class="edit-btn" onclick="editTask(${task.id})">Edit</button>
                <button class="delete-btn" onclick="deleteTask(${task.id})">Delete</button>
            </div>
        `;
        taskList.appendChild(li);
    });
}
